#pragma once

class memcheck
{
private:
	int strcount;
	char** allStr;
public:
	
	memcheck()
	{
		strcount = 0;
		allStr = NULL;
	}
	~memcheck()
	{
		for (int i = 0; i < strcount; i++)
			delete allStr[i];

		delete[] allStr;
	}
	friend ostream& operator<<(ostream& o,memcheck& l)
	{
		o << "� ��������� ���� ����������� ������� " << l.strcount << " �����\n";
		return o;
	}

	void del()
	{
		for (int i = 0; i < strcount; i++)
			delete allStr[i];
		
		delete[] allStr;

		strcount = 0;
		allStr = NULL;
	}
	void getStr(char *a)
	{
		char** strBuff=new char*[strcount+1];
		for (int i = 0; i < strcount; i++)
			strBuff[i] = allStr[i];

		strBuff[strcount++] = a;
		delete allStr;

		allStr = strBuff;
	}
};