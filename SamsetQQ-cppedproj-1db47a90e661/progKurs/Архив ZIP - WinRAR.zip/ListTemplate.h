#pragma once
#include <iostream>
#include <windows.h>
#include <fstream>
#include <string>

using namespace std;

template<class H>
class list
{
protected:
	char fillch = '_';
	
	class collection
	{
	public:
		static const int ptrcount = 5;
		H* ObjPtrs[ptrcount] = {NULL};
		bool loaded;
		collection *next;

		H*& operator[](int);
		
		collection();
		~collection();
		int add(H&);
		int add(int, H&);

		collection& operator =(collection&);
		
		void clearAll();
		int getnum();
	};

	collection *begin;
	collection *end;
public:
	const int maxptr= collection::ptrcount;
	list(char*);
	list();
	~list();
	collection& operator[](int);
	friend ostream& operator<< <>(ostream&,list<H>&);
	int add(H&);
	void add(int, H&);
	void remove(int);
	void removeAll();
	
	void clearAll();
	int getnum();
	
	virtual void sort()=0;
	virtual void balance()=0;
    virtual void savestr(char*)=0;
	virtual void loadstr(char*)=0;
};
/////////////////////////////////����������� ������� ������ "collection"///////////////////////////////////////////////


///////������������/�����������
template<class H>
list<H>::collection::collection()
{
	next = nullptr;
	for (int i = 0; i<collection::ptrcount; i++)
	ObjPtrs[i] = nullptr;
}

template<class H>
list<H>::collection::~collection()
{
	cout << "����� ����������� �������� ������" << endl;
}
///////

///////������ ���������� ������ "collection"
template<class H>
int list<H>::collection::add(H& a)
{
	for (int i = 0; i < collection::ptrcount - 1; i++)
	{
		if (this->ObjPtrs[i] == nullptr)
		{
			this->ObjPtrs[i] = &a;
			return i;
		}
	}
	return add(0, a);
}

template<class H>
int list<H>::collection::add(int i, H& a)
{
	if (ObjPtrs[i] == nullptr)
		ObjPtrs[i] = &a;
	else
	{
		int k = i + 1;
		for (; ObjPtrs[k] != nullptr && k < (ptrcount - 1); k++);
		int freespace = collection::ptrcount-1 - this->getnum();
		if (freespace == 0)
		{
			collection* t = new collection;
			t->next = this->next;
			this->next = t;
			int half = (collection::ptrcount - 1) / 2;
			for (int i=0; i < half; i++)
				t->add(*this->ObjPtrs[i + (collection::ptrcount - 1 - half)]);

			for (; k > i; k--)
				ObjPtrs[k] = ObjPtrs[k - 1];
		}
		if (freespace != 0 && k == collection::ptrcount - 2)
		{
			this->add(*ObjPtrs[collection::ptrcount - 2]);
		}
		for (; k > i; k--)
			ObjPtrs[k] = ObjPtrs[k - 1];

			ObjPtrs[i] = &a;

	}
	return i;
}

template<class H>
H*& list<H>::collection::operator[](int i)
{
		return (*this).ObjPtrs[i];
}

template<class H>
typename list<H>::collection& list<H>::collection::operator=(collection &b)
{
	if (this != &b)
	{
		this->count = b.count;
		this->next = b.next;
		for (int i = 0; i < this->ptrcount;)
			this->ObjPtrs[i] = b.ObjPtrs[i];
	}
	return *this;
}

template<class H>
int list<H>::collection::getnum()
{
	int r=0;
	for (int i = 0; i < this->ptrcount - 1; i++)
	{
		if (this->ObjPtrs[i] != NULL)
			r++;
	}
	return r;
}
///////////////////////////////////////////////����� ����������� ������� ���������� ������ "collection"//////////////////////////////////////////////////


///////////////////////////////////////////////����������� ������� ������ "list"/////////////////////////////////////////////////////////////

//////// ������������/�����������
template<class H>
list<H>::list()
{
	begin = nullptr;
	end = begin;
}

template<class H>
list<H>::list(char* h)
{
	begin = nullptr;
	end = begin;
	loadstr(h);
}

template<class H>
list<H>::~list()
{
	int c = getnum();
	collection* p = begin;
	collection* temp;
	for (int i = 0; p != nullptr; i++)
	{
			temp = p;
			p = p->next;
			delete temp;
	}
}
////////

////////������ ���������� ������ "list"
template<class H>
int list<H>::add(H& a)
{
	int count = getnum();
	if (count == 0)
	{
		begin = new collection;
		end = begin;
		count = getnum();
	}
	
	for (int i = 0; i < count; i++)
	{
		for (int j = 0; j < collection::ptrcount-1; j++)
		{
			if ((*this)[i][j] == nullptr)
			{
				(*this)[i][j]=&a;
				return i;
			}
		}
	}
	end->next = new collection;
	int half = (collection::ptrcount - 1) / 2;
	for (int i=0; i < half; i++)
		end->next->ObjPtrs[i] = end->ObjPtrs[i + (collection::ptrcount - 1 - half)];
	collection* tm = end->next;
	tm->add(a);
	end = end->next;
	return tm->getnum();
}

template<class H>
void list<H>::add(int i, H& a)
{
	return ((*this)[i].add(a));
}

template<class H>
int list<H>::getnum()
{
	collection* p = begin;
	int count = 0;
	while (p != nullptr)
	{
		p = p->next;
		count++;
	}
	return count;
}

template<class H>
typename list<H>::collection& list<H>::operator[](int i)
{
	collection* p = begin;
	for (int j = 0; j < i; j++)
		p = p->next;
	return *p;
}
template<class H>
ostream& operator<< <>(ostream& o,list<H>& l)
{
	o << "-----------------------------" << endl;
	for (int i = 0; i < l.getnum(); i++)
	{
		for (int j = 0, count = l[i].getnum(); j < count; j++)
		{
			
			o << *(l[i][j]) << endl;
		}
		o << "-----------------------------" << endl;
	}
	return o;
}

template<class H>
void list<H>::removeAll()
{
	while (&begin != &end)
	{
		collection* t;
		t = begin;
		begin = begin->next;
		delete t;
	}
	begin = nullptr;
	end = begin;
}

template<class H>
void list<H>::remove(int i)
{
	int j = getnum();
	if (i == 0)
	{
		collection* t = begin;
		begin = begin->next;
		delete t;
		return;
	}
	if (i == j - 1)
	{
		end = &(*this)[j-2];
		delete end->next;
		end->next = nullptr;
		return;
	}
	collection* pr = &(*this)[i-1];
	collection* t = &(*this)[i];
	pr->next = pr->next->next;
	delete t;
	return;
}

template<class H>
void list<H>::collection::clearAll()
{
	for (int i = 0; i < collection::ptrcount-1; i++)
		*(*this)[i] = NULL;
}
template<class H>
void list<H>::clearAll()
{
	int count= getnum()
	for (int i = 0; i < count; i++)
		(*this)[i]->clearAll();
}
///////////////////////////////////////////////����� ����������� ������� ���������� ������ "list"//////////////////////////////////////////////////

