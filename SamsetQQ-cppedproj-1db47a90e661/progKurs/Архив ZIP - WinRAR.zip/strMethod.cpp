#include "strList.h"

strList::~strList()
{
	cout << "strList ����������";
}

void strList::sort()
{
	int listsize = getnum();
	int maxcollsize = (collection::ptrcount - 1);
	int lineidx = 0;
	int lineidx_M = 0;
	int min_i;
	int min_j;
	
	for (; lineidx < listsize*maxcollsize; lineidx++)
	{
		lineidx_M = lineidx;
		 while (((*this)[lineidx_M / maxcollsize][lineidx_M % maxcollsize]) == nullptr && lineidx_M < listsize*maxcollsize-1)
			lineidx_M++;
		char* min = (*this)[lineidx_M / maxcollsize][lineidx_M % maxcollsize];
		min_i = lineidx_M / maxcollsize;
		min_j = lineidx_M % maxcollsize;
		lineidx_M++;
		for (; lineidx_M < listsize*maxcollsize; lineidx_M++)
		{
			int i = lineidx_M / maxcollsize;
			int j = lineidx_M % maxcollsize;
			if ((*this)[i][j] != nullptr)
			{
				if (compare((*this)[i][j], min))
				{
					min = (*this)[i][j];
					min_i = i;
					min_j = j;
				}
			}
		}
		char* temp = (*this)[lineidx / maxcollsize][lineidx % maxcollsize];
		if (temp == NULL)
		{
			(*this)[lineidx / maxcollsize][lineidx % maxcollsize] = min;
			(*this)[min_i][min_j] = temp;
		}
		else
		{
			if (&temp != &min)
			{
				(*this)[lineidx / maxcollsize][lineidx % maxcollsize] = min;
				(*this)[min_i][min_j] = temp;
			}
		}
	}
}

void strList::balance()
{
	int listsize = getnum();
	int maxcollsize = (collection::ptrcount - 1);
	int maxl;
	int lineidx = 0;
	while ((*this)[lineidx / maxcollsize][lineidx % maxcollsize] == nullptr)
		lineidx++;
	int charc = 0;
	while ((((*this)[lineidx / maxcollsize][lineidx % maxcollsize])[charc++]) != '\0');
	maxl = charc;
	lineidx++;
	for (; lineidx < listsize*maxcollsize; lineidx++)
	{
		int i = lineidx / maxcollsize;
		int j = lineidx % maxcollsize;
		if ((*this)[i][j] != nullptr)
		{
			charc = 0;
			while ((((*this)[i][j])[charc++]) != '\0');
			if (charc > maxl)
				maxl = charc;
		}
	}
	lineidx = 0;
	for (; lineidx < listsize*maxcollsize; lineidx++)
	{
		int i = lineidx / maxcollsize;
		int j = lineidx % maxcollsize;
		if ((*this)[i][j] != nullptr)
		{
			charc = 0;
			while ((((*this)[i][j])[charc++]) != '\0');
			char* t = new char[maxl];
			t[maxl - 1] = '\0';
			charc--;
			for (int o = 0; o < charc; o++)
				t[o] = (((*this)[i][j]))[o];

			(*this)[i][j] = t;
			for (int h = charc; (((*this)[i][j])[h]) != '\0'; h++)
				t[h] = fillch;
			// ������ ������ �� ���������, �.� ��� const char* � �������� new �� �������������
		}
	}
}

void strList::savestr(char *path)
{
	int listsize = getnum();
	int collcount = collection::ptrcount-1;
	int strl;
	ofstream out(path, ios::app);

	if (out)
	{
		out.write((char*)&listsize, sizeof(int));
		for (int i = 0; i < listsize; i++)
		{
			int pcount = (*this)[i].getnum();
			if (pcount != 0)
			{
				out.write((char*)&pcount, sizeof(int));
				for (int j = 0; j < collcount; j++)
				{
					if ((*this)[i][j] != nullptr)
					{
						out.write((char*)&j, sizeof(int));
						strl = 0;
						while ((((*this)[i][j])[strl++]) != '\0');
						out.write((*this)[i][j], sizeof(char)*strl);
					}
				}
			}
		}
		out.close();
	}
}

void strList::loadstr(char* path)
{
	if ((*this).getnum() != 0)
		(*this).removeAll();

	ifstream in(path, ios::app);
	if (in)
	{
		string* endstr;
		int r;
		in.read((char*)&r, sizeof(int));
		begin = new collection;
		end = begin;
		for (int i = 0; i < r - 1; i++)
			end = end->next = new collection;

		for (int i = 0; i < r; i++)
		{
			int size;
			in.read((char*)&size, sizeof(int));
			for (int j = 0; j < size; j++)
			{
				
				int pos;
				in.read((char*)&pos, sizeof(int));

				int strl = 0;
				char p = 1;
				while (p != '\0')
				{
					in.read((char*)&p, sizeof(char));
					strl++;
				}

				char*buff = new char[strl];;

				cout << in.tellg() << endl;
				int filepos = in.tellg();
				in.seekg(filepos - strl, ios::beg);
				cout << in.tellg() << endl;
				in.read(buff, sizeof(char)*strl);

				if (pos >= (*this)[0].ptrcount)
				{
					if (&(*this)[r] == nullptr)
						end = end->next = new collection;
					if (end->getnum() == collection::ptrcount - 1)
						end = end->next = new collection;
					end->add(*buff);
				}
				else
					(*this)[i][pos] = buff;
			}
		}

	}
}

bool strList::compare(char* a, char* b)
{
	//if a<b => return true
	int minl = 0;
	int a_size = 0;
	int b_size = 0;
	while (a[a_size++] != '\0');
	while (b[b_size++] != '\0');

	if (a_size < b_size)
		minl = a_size;
	else
		minl = b_size;

	for (int h = 0; h < minl - 1; h++)
	{
		if (a[h] > b[h])
			return false;
		if (a[h] < b[h])
			return true;
	}
	if (a_size == b_size)
		return false;
	if (a_size < b_size)
		return true;
	else
		return false;
}



